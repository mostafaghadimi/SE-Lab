package main;

public interface Shape {
    double computeArea();
}