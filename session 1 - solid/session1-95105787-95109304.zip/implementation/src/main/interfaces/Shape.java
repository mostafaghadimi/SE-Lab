package interfaces;

public interface Shape {
    double computeArea();
}