package codeGenerator;

/**
 * Created by mohammad hosein on 6/27/2015.
 */
public enum Operation {
    ADD,
    AND,
    ASSIGN,
    EQ,
    JPF,
    JP,
    LT,
    MULT,
    NOT,
    PRINT,
    SUB
}
