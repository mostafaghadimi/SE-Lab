package selab.mvc.models.entities;

public enum Weekday {
    Saturday, Sunday, Monday, Tuesday, Wednesday, Thursday, Friday
}
