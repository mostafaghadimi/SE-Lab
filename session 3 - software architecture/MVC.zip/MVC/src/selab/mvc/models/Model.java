package selab.mvc.models;

public interface Model {
    String getPrimaryKey();
}
